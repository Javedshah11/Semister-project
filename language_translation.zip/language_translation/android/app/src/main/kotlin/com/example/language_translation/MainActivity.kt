package com.example.language_translation

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
